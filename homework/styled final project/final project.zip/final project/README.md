Generic HTML Template
=====================

Simple project template for my students. Includes a reset.css and a couple basic styles. Download this repository as a zip to use it.
